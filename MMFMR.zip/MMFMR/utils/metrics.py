# utils/metrics.py 或添加到现有文件中

import numpy as np
import torch
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.metrics import confusion_matrix, classification_report
import pandas as pd
import os


class AverageMeter(object):
    """
    计算并存储平均值和当前值
    用于跟踪训练过程中的损失和准确率
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.val = 0
        self.avg = 0
        self.sum = 0
        self.count = 0

    def update(self, val, n=1):
        # 确保 val 是标量，而不是张量
        if hasattr(val, 'item'):
            val = val.item()
        self.val = val
        self.sum += val * n
        self.count += n
        self.avg = self.sum / self.count


def accuracy(output, target, topk=(1,)):
    """
    计算指定k值的top-k准确率

    参数:
        output: 模型输出 (logits)
        target: 真实标签
        topk: 要计算的top-k值，例如(1,5)表示计算top-1和top-5准确率

    返回:
        包含指定top-k准确率的列表
    """
    with torch.no_grad():
        maxk = max(topk)
        batch_size = target.size(0)

        # 获取top-k预测
        _, pred = output.topk(maxk, 1, True, True)
        pred = pred.t()
        correct = pred.eq(target.view(1, -1).expand_as(pred))

        res = []
        for k in topk:
            correct_k = correct[:k].reshape(-1).float().sum(0, keepdim=True)
            res.append(correct_k.mul_(100.0 / batch_size))
        return res


def plot_confusion_matrix(cm, class_names, filename='confusion_matrix.png', normalize=False, title=None):
    """
    创建并保存混淆矩阵可视化

    参数:
        cm: 从sklearn.metrics.confusion_matrix获取的混淆矩阵
        class_names: 类别名称列表
        filename: 输出文件名
        normalize: 是否归一化混淆矩阵
        title: 图表标题

    返回:
        无，直接保存图像文件
    """
    # 设置中文字体支持（如果需要）
    plt.rcParams['font.sans-serif'] = ['SimHei']  # 用来正常显示中文标签
    plt.rcParams['axes.unicode_minus'] = False  # 用来正常显示负号

    # 创建图形
    plt.figure(figsize=(10, 8))

    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        fmt = '.2f'
        if title is None:
            title = '归一化混淆矩阵'
    else:
        fmt = 'd'
        if title is None:
            title = '混淆矩阵'

    # 绘制热力图
    sns.heatmap(cm, annot=True, fmt=fmt, cmap='Blues',
                xticklabels=class_names, yticklabels=class_names,
                cbar_kws={'label': '样本数量'})

    # 设置标题和标签
    plt.title(title, fontsize=16, fontweight='bold')
    plt.ylabel('真实标签', fontsize=14)
    plt.xlabel('预测标签', fontsize=14)
    plt.xticks(rotation=45, ha='right')
    plt.yticks(rotation=0)

    # 调整布局并保存
    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"混淆矩阵已保存为 {filename}")


def save_classification_report(y_true, y_pred, class_names, filename='classification_report.txt'):
    """
    保存详细的分类报告到文件

    参数:
        y_true: 真实标签
        y_pred: 预测标签
        class_names: 类别名称列表
        filename: 输出文件名

    返回:
        pandas DataFrame格式的分类报告
    """
    # 生成分类报告
    report = classification_report(y_true, y_pred, target_names=class_names, output_dict=True)

    # 转换为DataFrame以便更好地格式化
    report_df = pd.DataFrame(report).transpose()

    # 确保目录存在
    os.makedirs(os.path.dirname(filename) if os.path.dirname(filename) else '.', exist_ok=True)

    # 写入文件
    with open(filename, 'w', encoding='utf-8') as f:
        f.write("分类报告\n")
        f.write("=" * 50 + "\n\n")
        f.write(report_df.to_string())
        f.write("\n\n混淆矩阵:\n")
        f.write("=" * 50 + "\n")
        f.write(str(confusion_matrix(y_true, y_pred)))

    print(f"分类报告已保存为 {filename}")
    return report_df


def calculate_metrics(cm, class_names):
    """
    从混淆矩阵计算额外指标

    参数:
        cm: 混淆矩阵
        class_names: 类别名称列表

    返回:
        包含每个类别指标的字典
    """
    metrics = {}
    for i, class_name in enumerate(class_names):
        tp = cm[i, i]  # 真正例
        fp = cm[:, i].sum() - tp  # 假正例
        fn = cm[i, :].sum() - tp  # 假反例
        tn = cm.sum() - (tp + fp + fn)  # 真反例

        # 计算精确率、召回率和F1分数
        precision = tp / (tp + fp) if (tp + fp) > 0 else 0
        recall = tp / (tp + fn) if (tp + fn) > 0 else 0
        f1 = 2 * (precision * recall) / (precision + recall) if (precision + recall) > 0 else 0

        metrics[class_name] = {
            '精确率': precision,
            '召回率': recall,
            'F1分数': f1,
            '支持度': cm[i, :].sum()
        }

    return metrics


def save_training_history(train_losses, val_losses, train_accs, val_accs, filename='training_history.png'):
    """
    保存训练历史图表

    参数:
        train_losses: 训练损失列表
        val_losses: 验证损失列表
        train_accs: 训练准确率列表
        val_accs: 验证准确率列表
        filename: 输出文件名
    """
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 5))

    # 绘制损失曲线
    ax1.plot(train_losses, label='训练损失')
    ax1.plot(val_losses, label='验证损失')
    ax1.set_title('训练和验证损失')
    ax1.set_xlabel('Epoch')
    ax1.set_ylabel('损失')
    ax1.legend()
    ax1.grid(True)

    # 绘制准确率曲线
    ax2.plot(train_accs, label='训练准确率')
    ax2.plot(val_accs, label='验证准确率')
    ax2.set_title('训练和验证准确率')
    ax2.set_xlabel('Epoch')
    ax2.set_ylabel('准确率 (%)')
    ax2.legend()
    ax2.grid(True)

    plt.tight_layout()
    plt.savefig(filename, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"训练历史图表已保存为 {filename}")