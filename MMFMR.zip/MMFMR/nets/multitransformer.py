import torch
import torch.nn as nn
from nets.transformer import TransformerEncoder, PreNorm, Attention, FeedForward


class MultiTransformer(nn.Module):
    def __init__(self, num_modules, length, num_classes, dim, depth, heads, mlp_dim, dropout=0.1, emb_dropout=0.1):
        super(MultiTransformer, self).__init__()

        # 计算每个模块的深度
        depth_per_module = depth // num_modules

        # 创建多个Transformer编码器模块
        self.encoders = nn.ModuleList([
            TransformerEncoder(dim, depth_per_module, heads, 64, mlp_dim, dropout)
            for _ in range(num_modules)
        ])

        # 共享的CLS token和位置编码
        self.cls_token = nn.Parameter(torch.randn(1, 1, dim))
        self.pos_embedding = nn.Parameter(torch.randn(1, length + 1, dim))
        self.dropout = nn.Dropout(emb_dropout)

        # 分类头
        self.mlp_head = nn.Sequential(
            nn.LayerNorm(dim),
            nn.Linear(dim, num_classes)
        )

    def forward(self, x):
        # 打印输入形状以便调试
        print(f"Input shape: {x.shape}")

        # 处理不同维度的输入
        if x.dim() == 4:
            # 如果是4维 [batch, channels, height, width]，展平为3维 [batch, seq_len, dim]
            b, c, h, w = x.shape
            x = x.view(b, c, h * w).transpose(1, 2)  # [batch, h*w, c]
        elif x.dim() == 2:
            # 如果是2维 [batch, features]，添加序列维度
            x = x.unsqueeze(1)  # [batch, 1, features]

        # 现在x应该是3维的 [batch, seq_len, dim]
        b, n, d = x.shape

        # 添加CLS token和位置编码
        cls_tokens = self.cls_token.expand(b, -1, -1)
        x = torch.cat((cls_tokens, x), dim=1)
        x += self.pos_embedding[:, :(n + 1)]
        x = self.dropout(x)

        # 依次通过每个编码器模块
        for encoder in self.encoders:
            x = encoder(x)

        # 取CLS token的输出进行分类
        x = x[:, 0]  # 取CLS token
        return self.mlp_head(x)